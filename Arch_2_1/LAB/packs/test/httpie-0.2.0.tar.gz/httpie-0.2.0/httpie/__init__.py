"""
HTTPie - cURL for humans.

"""
__author__ = 'Jakub Roztocil'
__version__ = '0.2.0'
__licence__ = 'BSD'
